import { fail, ok } from "../../../../lib/api";
import { createClient } from "@supabase/supabase-js";

const url=process.env.NEXT_PUBLIC_SUPABASE_URL||"https://ldffgetuzoeupuhoaubn.supabase.co";
const key=process.env.SUPABASE_SERVICE_ROLE_KEY;

export async function POST(request:Request,{params}:{params:Promise<{channel:string}>}){
 const {channel}=await params;
 if(!["whatsapp","sms","email"].includes(channel))return fail("INVALID_CHANNEL","Unknown webhook channel",404);
 if(!key)return fail("WEBHOOK_NOT_CONFIGURED","Server webhook credentials are not configured",503);
 try{
  const body=await request.json();
  const eventId=String(body.id||body.event_id||body.message_id||"");
  if(!eventId)return fail("EVENT_ID_REQUIRED","Provider event id is required");
  const sb=createClient(url,key,{auth:{persistSession:false}});
  const {error}=await sb.schema("engagex").from("webhook_events").insert({provider:channel,provider_event_id:eventId,event_type:String(body.type||body.status||"event"),payload:body});
  if(error && error.code!=="23505")throw error;
  return ok({received:true,duplicate:error?.code==="23505"});
 }catch{ return fail("INVALID_WEBHOOK","Webhook payload could not be processed"); }
}
