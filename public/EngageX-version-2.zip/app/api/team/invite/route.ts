import { createClient } from "@supabase/supabase-js";
import { apiError, fail, ok } from "../../../../lib/api";
import { createAuthenticatedSupabase } from "../../../../lib/server-supabase";

const url=process.env.NEXT_PUBLIC_SUPABASE_URL||"https://ldffgetuzoeupuhoaubn.supabase.co";
const serviceKey=process.env.SUPABASE_SERVICE_ROLE_KEY;

export async function POST(request:Request){
 try{
  if(!serviceKey)return fail("ADMIN_SERVICE_NOT_CONFIGURED","Server invite credentials are not configured",503);
  const userClient=createAuthenticatedSupabase(request);
  const b=await request.json();
  if(!b.email||!b.role)return fail("INVITE_FIELDS_REQUIRED","Email and role are required");
  const org=await userClient.rpc("engagex_my_org");
  if(org.error||!org.data)throw org.error||new Error("NO_WORKSPACE");
  const svc=createClient(url,serviceKey,{auth:{persistSession:false}});
  const invite=await svc.auth.admin.inviteUserByEmail(String(b.email).trim().toLowerCase());
  if(invite.error)throw invite.error;
  const uid=invite.data.user?.id;
  if(!uid)throw new Error("INVITE_USER_NOT_CREATED");
  const link=await svc.rpc("engagex_team_attach_user",{p_organization_id:org.data,p_user_id:uid,p_role:b.role});
  if(link.error)throw link.error;
  return ok({invited:true,user_id:uid});
 }catch(e){return apiError(e)}
}
