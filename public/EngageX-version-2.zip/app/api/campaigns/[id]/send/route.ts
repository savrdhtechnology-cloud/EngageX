import { apiError, ok } from "../../../../../lib/api";
import { createAuthenticatedSupabase } from "../../../../../lib/server-supabase";
export async function POST(request:Request,{params}:{params:Promise<{id:string}>}){try{const {id}=await params;const sb=createAuthenticatedSupabase(request);const {data,error}=await sb.rpc("engagex_campaign_queue",{p_campaign_id:id});if(error)throw error;return ok(data)}catch(e){return apiError(e)}}
