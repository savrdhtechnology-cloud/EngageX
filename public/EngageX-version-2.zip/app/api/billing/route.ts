import { apiError, ok } from "../../../lib/api";
import { createAuthenticatedSupabase } from "../../../lib/server-supabase";
export async function GET(request:Request){try{const sb=createAuthenticatedSupabase(request);const {data,error}=await sb.rpc("engagex_billing_summary");if(error)throw error;return ok(data)}catch(e){return apiError(e)}}
