import { apiError, ok } from "../../../lib/api";
import { createAuthenticatedSupabase } from "../../../lib/server-supabase";

export async function GET(request:Request){
 try{
  const sb=createAuthenticatedSupabase(request);
  const [stats,campaigns,activity,timeseries]=await Promise.all([
   sb.rpc("engagex_dashboard_stats"),
   sb.rpc("engagex_recent_campaigns",{p_limit:5}),
   sb.rpc("engagex_recent_activity",{p_limit:8}),
   sb.rpc("engagex_dashboard_timeseries",{p_days:14})
  ]);
  for(const r of [stats,campaigns,activity,timeseries]) if(r.error) throw r.error;
  return ok({stats:stats.data,campaigns:campaigns.data||[],activity:activity.data||[],timeseries:timeseries.data||[]});
 }catch(e){return apiError(e)}
}
