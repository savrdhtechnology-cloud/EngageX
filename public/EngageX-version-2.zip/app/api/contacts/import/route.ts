import * as XLSX from "xlsx";
import { apiError, fail, ok } from "../../../../lib/api";
import { createAuthenticatedSupabase } from "../../../../lib/server-supabase";

function normalize(row:Record<string,unknown>) {
  const get=(...keys:string[])=>{for(const k of keys){const hit=Object.keys(row).find(x=>x.trim().toLowerCase()===k);if(hit)return String(row[hit]??"").trim()}return ""};
  return {
    name:get("name","full name","fullname"),
    first_name:get("first name","firstname"),
    last_name:get("last name","lastname"),
    mobile:get("mobile","phone","phone number","mobile number"),
    email:get("email","email address"),
    company:get("company","company name"),
    city:get("city"),state:get("state"),country:get("country"),
    whatsapp_consent:["yes","true","1","opted in"].includes(get("whatsapp consent","whatsapp opt-in").toLowerCase()),
    sms_consent:["yes","true","1","opted in"].includes(get("sms consent","sms opt-in").toLowerCase()),
    email_consent:["yes","true","1","opted in"].includes(get("email consent","email opt-in").toLowerCase())
  };
}
export async function POST(request:Request){
 try{
  const sb=createAuthenticatedSupabase(request);
  const form=await request.formData();
  const file=form.get("file");
  if(!(file instanceof File))return fail("FILE_REQUIRED","CSV or XLSX file is required");
  if(file.size>10*1024*1024)return fail("FILE_TOO_LARGE","Import file must be 10 MB or smaller",413);
  const buf=Buffer.from(await file.arrayBuffer());
  const wb=XLSX.read(buf,{type:"buffer"});
  const sheet=wb.Sheets[wb.SheetNames[0]];
  const raw=XLSX.utils.sheet_to_json<Record<string,unknown>>(sheet,{defval:""});
  if(raw.length>10000)return fail("ROW_LIMIT","Import supports up to 10,000 rows per file",413);
  const rows=raw.map(normalize);
  const preview={
    total:rows.length,
    valid:rows.filter(r=>r.mobile||r.email).length,
    invalid:rows.filter(r=>!r.mobile&&!r.email).length,
    missing_phone:rows.filter(r=>!r.mobile).length,
    missing_email:rows.filter(r=>!r.email).length,
    detected_columns:Object.keys(raw[0]||{}),
    sample:rows.slice(0,10)
  };
  if(form.get("mode")==="preview")return ok(preview);
  const {data,error}=await sb.rpc("engagex_contacts_import_batch",{p_rows:rows,p_filename:file.name});
  if(error)throw error;
  return ok({...preview,...data});
 }catch(e){return apiError(e)}
}
