import { createClient } from "@supabase/supabase-js";
import { apiError, fail, ok } from "../../../../lib/api";
import { createAuthenticatedSupabase } from "../../../../lib/server-supabase";
import { encryptSecret } from "../../../../lib/secret-crypto";
const url=process.env.NEXT_PUBLIC_SUPABASE_URL||"https://ldffgetuzoeupuhoaubn.supabase.co";
const serviceKey=process.env.SUPABASE_SERVICE_ROLE_KEY;
export async function POST(request:Request){
 try{
  if(!serviceKey)return fail("ADMIN_SERVICE_NOT_CONFIGURED","Server credential storage is not configured",503);
  const userClient=createAuthenticatedSupabase(request);
  const b=await request.json();
  if(!b.provider||!b.channel||!b.secret)return fail("CREDENTIAL_FIELDS_REQUIRED","Provider, channel and secret are required");
  const org=await userClient.rpc("engagex_my_org"); if(org.error||!org.data)throw org.error||new Error("NO_WORKSPACE");
  const integration=await userClient.rpc("engagex_integrations_upsert",{p_provider:b.provider,p_channel:b.channel,p_status:"configured",p_config:b.config||{}});
  if(integration.error)throw integration.error;
  const encrypted=encryptSecret(String(b.secret));
  const svc=createClient(url,serviceKey,{auth:{persistSession:false}});
  const stored=await svc.rpc("engagex_provider_credential_store",{p_organization_id:org.data,p_integration_id:integration.data,p_provider:b.provider,p_secret_ciphertext:"\\x"+encrypted.toString("hex"),p_key_version:1});
  if(stored.error)throw stored.error;
  return ok({configured:true,integration_id:integration.data});
 }catch(e){return apiError(e)}
}
