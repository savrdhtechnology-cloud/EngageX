import { fail, ok } from "../../../../lib/api";
import { createAuthenticatedSupabase } from "../../../../lib/server-supabase";
export async function POST(request:Request){
 try{
  createAuthenticatedSupabase(request);
  const b=await request.json();
  if(!b.provider||!b.secret)return fail("CREDENTIAL_FIELDS_REQUIRED","Provider and credential are required");
  if(b.provider==="resend"){
   const r=await fetch("https://api.resend.com/domains",{headers:{Authorization:"Bearer "+b.secret}});
   return r.ok?ok({connected:true,message:"Resend credential verified"}):fail("CONNECTION_FAILED","Resend rejected the credential",400);
  }
  if(b.provider==="whatsapp_meta"){
   if(!b.phone_number_id)return fail("PHONE_NUMBER_ID_REQUIRED","WhatsApp phone number ID is required");
   const r=await fetch("https://graph.facebook.com/v21.0/"+encodeURIComponent(b.phone_number_id)+"?fields=display_phone_number,verified_name",{headers:{Authorization:"Bearer "+b.secret}});
   return r.ok?ok({connected:true,message:"WhatsApp Business credential verified"}):fail("CONNECTION_FAILED","WhatsApp Business API rejected the credential",400);
  }
  return fail("TEST_UNAVAILABLE","Live connection test is not implemented for this provider yet",501);
 }catch(e){return fail("CONNECTION_FAILED",e instanceof Error?e.message:"Connection test failed",400)}
}
