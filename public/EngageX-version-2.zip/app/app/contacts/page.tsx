"use client";
import { ChangeEvent,useEffect,useMemo,useState } from "react";
import CommercialShell from "../components/CommercialShell";
import { apiFetch } from "../../../lib/client-api";

type Contact={id:string;name:string|null;first_name:string|null;last_name:string|null;mobile:string|null;email:string|null;company:string|null;job_title:string|null;city:string|null;state:string|null;country:string|null;notes:string|null;source:string|null;tags:string[];status:string;whatsapp_consent:boolean;sms_consent:boolean;email_consent:boolean;created_at:string};
type FormState={first_name:string;last_name:string;mobile:string;email:string;company:string;job_title:string;city:string;state:string;country:string;notes:string;source:string;tags:string;whatsapp_consent:boolean;sms_consent:boolean;email_consent:boolean};
const blank:FormState={first_name:"",last_name:"",mobile:"",email:"",company:"",job_title:"",city:"",state:"",country:"",notes:"",source:"manual",tags:"",whatsapp_consent:false,sms_consent:false,email_consent:false};

export default function Contacts(){
 const [rows,setRows]=useState<Contact[]>([]),[query,setQuery]=useState(""),[loading,setLoading]=useState(true),[error,setError]=useState(""),[notice,setNotice]=useState("");
 const [form,setForm]=useState<FormState>(blank),[open,setOpen]=useState(false),[editing,setEditing]=useState<Contact|null>(null),[selected,setSelected]=useState<string[]>([]);
 const [importPreview,setImportPreview]=useState<any>(null),[importFile,setImportFile]=useState<File|null>(null);

 async function load(q=""){setLoading(true);setError("");try{const data=await apiFetch<Contact[]>("/api/contacts?q="+encodeURIComponent(q)+"&limit=100");setRows(data)}catch(e){setError(e instanceof Error?e.message:"Could not load contacts")}finally{setLoading(false)}}
 useEffect(()=>{load()},[]);
 useEffect(()=>{const t=setTimeout(()=>load(query),300);return()=>clearTimeout(t)},[query]);

 const active=useMemo(()=>rows.filter(x=>x.status==="active").length,[rows]);
 const duplicateCount=useMemo(()=>{const seen=new Set<string>();let n=0;for(const r of rows){for(const k of [r.mobile?.trim(),r.email?.trim().toLowerCase()])if(k){if(seen.has(k))n++;else seen.add(k)}}return n},[rows]);

 function edit(c:Contact){setEditing(c);setForm({first_name:c.first_name||"",last_name:c.last_name||"",mobile:c.mobile||"",email:c.email||"",company:c.company||"",job_title:c.job_title||"",city:c.city||"",state:c.state||"",country:c.country||"",notes:c.notes||"",source:c.source||"manual",tags:(c.tags||[]).join(", "),whatsapp_consent:!!c.whatsapp_consent,sms_consent:!!c.sms_consent,email_consent:!!c.email_consent});setOpen(true)}
 function startNew(){setEditing(null);setForm(blank);setOpen(true)}
 async function save(){setError("");try{const body={...form,tags:form.tags.split(",").map(x=>x.trim()).filter(Boolean)};if(editing)await apiFetch("/api/contacts/"+editing.id,{method:"PUT",body:JSON.stringify(body)});else await apiFetch("/api/contacts",{method:"POST",body:JSON.stringify(body)});setNotice(editing?"Contact updated.":"Contact created.");setOpen(false);setEditing(null);setForm(blank);await load(query)}catch(e){setError(e instanceof Error?e.message:"Save failed")}}
 async function remove(id:string){if(!confirm("Delete this contact?"))return;try{await apiFetch("/api/contacts/"+id,{method:"DELETE"});setNotice("Contact deleted.");setSelected(s=>s.filter(x=>x!==id));await load(query)}catch(e){setError(e instanceof Error?e.message:"Delete failed")}}
 async function bulkDelete(){if(!selected.length||!confirm(`Delete ${selected.length} selected contacts?`))return;for(const id of selected)await apiFetch("/api/contacts/"+id,{method:"DELETE"});setSelected([]);setNotice("Selected contacts deleted.");await load(query)}
 function exportCsv(){const list=selected.length?rows.filter(r=>selected.includes(r.id)):rows;const q=(v:unknown)=>'"'+String(v??"").replaceAll('"','""')+'"';const csv=["Name,Mobile,Email,Company,City,Status,WhatsApp Consent,SMS Consent,Email Consent",...list.map(r=>[r.name,r.mobile,r.email,r.company,r.city,r.status,r.whatsapp_consent,r.sms_consent,r.email_consent].map(q).join(","))].join("\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="engagex-contacts.csv";a.click();URL.revokeObjectURL(a.href)}
 async function previewImport(e:ChangeEvent<HTMLInputElement>){const file=e.target.files?.[0];if(!file)return;setImportFile(file);const fd=new FormData();fd.append("file",file);fd.append("mode","preview");try{setImportPreview(await apiFetch("/api/contacts/import",{method:"POST",body:fd}));setNotice("Import preview ready.")}catch(err){setError(err instanceof Error?err.message:"Import preview failed")}}
 async function commitImport(){if(!importFile)return;const fd=new FormData();fd.append("file",importFile);fd.append("mode","import");try{const r:any=await apiFetch("/api/contacts/import",{method:"POST",body:fd});setNotice(`Imported ${r.inserted||0}; duplicates ${r.duplicates||0}; invalid ${r.invalid||0}.`);setImportPreview(null);setImportFile(null);await load(query)}catch(err){setError(err instanceof Error?err.message:"Import failed")}}

 return <CommercialShell title="Contacts" subtitle="Audience, consent and customer profile management.">
  {error&&<div className="notice errorNotice">{error}</div>}{notice&&<div className="notice">{notice}</div>}
  <div className="commercialToolbar">
   <div className="leftActions"><input className="searchField" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search name, mobile, email..."/></div>
   <div className="rightActions">
    <label className="cbtn secondary fileBtn">Import Excel / CSV<input type="file" accept=".csv,.xlsx,.xls" onChange={previewImport}/></label>
    <button className="cbtn secondary" onClick={exportCsv}>Export CSV</button>
    <button className="cbtn primary" onClick={startNew}>+ Add Contact</button>
   </div>
  </div>
  {selected.length>0&&<div className="bulkBar"><b>{selected.length} selected</b><span>WhatsApp</span><span>SMS</span><span>Email</span><button onClick={exportCsv}>Export</button><button className="danger" onClick={bulkDelete}>Delete</button></div>}
  {importPreview&&<section className="panel importPreview"><h3>Import Preview</h3><p>Detected columns: {(importPreview.detected_columns||[]).join(", ")||"None"}</p><div className="metricGrid compact"><article><span>Total Rows</span><strong>{importPreview.total}</strong></article><article><span>Valid</span><strong>{importPreview.valid}</strong></article><article><span>Invalid</span><strong>{importPreview.invalid}</strong></article><article><span>Missing Email</span><strong>{importPreview.missing_email}</strong></article></div><div className="commercialToolbar"><button className="cbtn secondary" onClick={()=>{setImportPreview(null);setImportFile(null)}}>Cancel</button><button className="cbtn primary" onClick={commitImport}>Import Valid Rows</button></div></section>}
  <div className="metricGrid"><article><span>Loaded Contacts</span><strong>{rows.length}</strong><small>Current filtered result</small></article><article><span>Active</span><strong>{active}</strong><small>Reachable contacts</small></article><article><span>Selected</span><strong>{selected.length}</strong><small>Bulk actions</small></article><article><span>Possible Duplicates</span><strong>{duplicateCount}</strong><small>Phone / email match</small></article></div>

  <section className="panel">
   <h3>Contact Directory</h3><p>Name, mobile, email, tags and channel consent. Messaging actions must respect opt-in status.</p>
   {loading?<div className="emptyBox"><div><b>Loading contacts…</b></div></div>:rows.length===0?<div className="emptyBox"><div><b>No contacts yet</b><p>Import Excel/CSV or add your first contact.</p></div></div>:
   <div className="responsiveTable"><table className="dataTable"><thead><tr><th><input type="checkbox" checked={selected.length===rows.length&&rows.length>0} onChange={e=>setSelected(e.target.checked?rows.map(r=>r.id):[])}/></th><th>Contact</th><th>Mobile / Email</th><th>Company</th><th>Consent</th><th>Status</th><th>Actions</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td><input type="checkbox" checked={selected.includes(r.id)} onChange={e=>setSelected(s=>e.target.checked?[...s,r.id]:s.filter(x=>x!==r.id))}/></td><td><b>{r.name||"Unnamed"}</b><small className="cellSub">{r.city||r.state||"—"}</small></td><td>{r.mobile||"—"}<small className="cellSub">{r.email||"—"}</small></td><td>{r.company||"—"}</td><td><div className="consentBadges"><span className={r.whatsapp_consent?"on":""}>WA</span><span className={r.sms_consent?"on":""}>SMS</span><span className={r.email_consent?"on":""}>Email</span></div></td><td><span className="status">{r.status}</span></td><td><button className="tableAction" onClick={()=>edit(r)}>Edit</button><button className="tableAction dangerText" onClick={()=>remove(r.id)}>Delete</button></td></tr>)}</tbody></table></div>}
  </section>

  {open&&<div className="modalBackdrop"><div className="modalCard"><div className="modalHead"><div><small>{editing?"EDIT CONTACT":"NEW CONTACT"}</small><h3>{editing?"Update customer":"Add customer"}</h3></div><button onClick={()=>setOpen(false)}>×</button></div><div className="formGrid">
   <div className="field"><label>First Name</label><input value={form.first_name} onChange={e=>setForm({...form,first_name:e.target.value})}/></div>
   <div className="field"><label>Last Name</label><input value={form.last_name} onChange={e=>setForm({...form,last_name:e.target.value})}/></div>
   <div className="field"><label>Mobile</label><input value={form.mobile} onChange={e=>setForm({...form,mobile:e.target.value})}/></div>
   <div className="field"><label>Email</label><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></div>
   <div className="field"><label>Company</label><input value={form.company} onChange={e=>setForm({...form,company:e.target.value})}/></div>
   <div className="field"><label>Job Title</label><input value={form.job_title} onChange={e=>setForm({...form,job_title:e.target.value})}/></div>
   <div className="field"><label>City</label><input value={form.city} onChange={e=>setForm({...form,city:e.target.value})}/></div>
   <div className="field"><label>State</label><input value={form.state} onChange={e=>setForm({...form,state:e.target.value})}/></div>
   <div className="field"><label>Country</label><input value={form.country} onChange={e=>setForm({...form,country:e.target.value})}/></div>
   <div className="field"><label>Tags</label><input value={form.tags} onChange={e=>setForm({...form,tags:e.target.value})} placeholder="hot lead, msme"/></div>
   <div className="field full"><label>Notes</label><textarea value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/></div>
   <div className="field full"><label>Communication consent</label><div className="consentChecks"><label><input type="checkbox" checked={form.whatsapp_consent} onChange={e=>setForm({...form,whatsapp_consent:e.target.checked})}/> WhatsApp opt-in</label><label><input type="checkbox" checked={form.sms_consent} onChange={e=>setForm({...form,sms_consent:e.target.checked})}/> SMS opt-in</label><label><input type="checkbox" checked={form.email_consent} onChange={e=>setForm({...form,email_consent:e.target.checked})}/> Email opt-in</label></div></div>
  </div><div className="modalActions"><button className="cbtn secondary" onClick={()=>setOpen(false)}>Cancel</button><button className="cbtn primary" onClick={save}>{editing?"Save Changes":"Create Contact"}</button></div></div></div>}
 </CommercialShell>
}