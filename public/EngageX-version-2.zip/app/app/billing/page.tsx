"use client";
import { useEffect,useState } from "react";
import CommercialShell from "../components/CommercialShell";
import { apiFetch } from "../../../lib/client-api";

type Billing={plan_code:string;plan_name:string;status:string;message_credits:number;contact_limit:number|null;monthly_message_limit:number|null;monthly_price:number|null;whatsapp_usage:number;sms_usage:number;email_usage:number};
type Plan={code:string;name:string;monthly_price:number;contact_limit:number|null;monthly_message_limit:number|null;features:Record<string,unknown>};

export default function BillingPage(){
 const [b,setB]=useState<Billing|null>(null),[plans,setPlans]=useState<Plan[]>([]),[error,setError]=useState("");
 useEffect(()=>{Promise.all([apiFetch<Billing>("/api/billing"),apiFetch<Plan[]>("/api/plans")]).then(([x,p])=>{setB(x);setPlans(p)}).catch(e=>setError(e.message))},[]);
 const used=(b?.whatsapp_usage||0)+(b?.sms_usage||0)+(b?.email_usage||0);
 return <CommercialShell title="Billing" subtitle="Subscription, message credits, usage and invoices.">
  {error&&<div className="notice errorNotice">{error}</div>}
  <div className="metricGrid">
   <article><span>Current Plan</span><strong>{b?.plan_name||"—"}</strong><small>{b?.status||"Loading"}</small></article>
   <article><span>Message Credits</span><strong>{b?.message_credits??0}</strong><small>Workspace balance</small></article>
   <article><span>Current Usage</span><strong>{used}</strong><small>{b?.monthly_message_limit?("of "+b.monthly_message_limit+" monthly"):"Configurable"}</small></article>
   <article><span>Contacts Limit</span><strong>{b?.contact_limit??"—"}</strong><small>Plan allowance</small></article>
  </div>
  <section className="panel"><h3>Channel Usage</h3><p>Usage is recorded from the message ledger and provider delivery workflow.</p><div className="usageGrid"><div><span>WhatsApp</span><b>{b?.whatsapp_usage??0}</b></div><div><span>SMS</span><b>{b?.sms_usage??0}</b></div><div><span>Email</span><b>{b?.email_usage??0}</b></div></div></section>
  <section className="panel" style={{marginTop:14}}><h3>Available Plans</h3><p>Plan configuration is stored in the database. A billing provider must be connected before real upgrades, downgrades or payments are enabled.</p><div className="planCards">{plans.map(p=><article key={p.code}><h4>{p.name}</h4><p>{p.monthly_price?("₹"+Number(p.monthly_price).toLocaleString("en-IN")+" / month"):"Custom pricing"}</p><small>{p.contact_limit?(p.contact_limit.toLocaleString()+" contacts"):"Custom contact limit"} · {p.monthly_message_limit?(p.monthly_message_limit.toLocaleString()+" messages"):"Custom usage"}</small><button className="cbtn secondary" disabled={p.code===b?.plan_code}>{p.code===b?.plan_code?"Current Plan":"Billing Provider Required"}</button></article>)}</div></section>
 </CommercialShell>
}