"use client";
import { useEffect,useMemo,useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { BarChart3,Bell,Bot,ContactRound,CreditCard,LayoutDashboard,LogOut,Mail,Megaphone,MessageCircle,MessageSquareText,Settings,Sparkles,Users,Workflow,Plus,Upload,Send,GitBranch } from "lucide-react";
import { supabase } from "../../../lib/supabase";
import { apiFetch } from "../../../lib/client-api";
import "./dashboard.css";

const menu=[["Dashboard","/app/dashboard",LayoutDashboard],["Contacts","/app/contacts",ContactRound],["Campaigns","/app/campaigns",Megaphone],["Templates","/app/templates",MessageSquareText],["Automations","/app/automations",Workflow],["Analytics","/app/analytics",BarChart3],["Integrations","/app/integrations",Bot],["Team & Roles","/app/team",Users],["Billing","/app/billing",CreditCard],["Settings","/app/settings",Settings]] as const;

type DashboardData={
 stats:{contacts:number;new_contacts:number;active_contacts:number;campaigns:number;running_campaigns:number;messages_sent:number;delivered:number;failed:number;pending:number;whatsapp:number;sms:number;email:number}|null;
 campaigns:Array<{id:string;name:string;status:string;channels:string[];created_at:string;scheduled_at:string|null}>;
 activity:Array<{id:string;action:string;resource_type:string|null;resource_id:string|null;created_at:string}>;
 timeseries:Array<{dt:string;total:number;whatsapp:number;sms:number;email:number;delivered:number;failed:number}>;
};

export default function Dashboard(){
 const router=useRouter();
 const [email,setEmail]=useState("");
 const [ready,setReady]=useState(false);
 const [data,setData]=useState<DashboardData|null>(null);
 const [error,setError]=useState("");
 useEffect(()=>{supabase.auth.getSession().then(({data:s})=>{if(!s.session){router.replace("/login");return}setEmail(s.session.user.email||"Admin");setReady(true);apiFetch<DashboardData>("/api/dashboard").then(setData).catch(e=>setError(e.message))})},[router]);
 async function logout(){await supabase.auth.signOut();router.replace("/login")}
 const s=data?.stats;
 const deliveryRate=useMemo(()=>s&&s.messages_sent?Math.round((s.delivered/s.messages_sent)*100):null,[s]);
 const max=useMemo(()=>Math.max(1,...(data?.timeseries||[]).map(x=>Number(x.total))),[data]);
 if(!ready)return <div className="crmLoading">Loading EngageX workspace…</div>;
 return <main className="crmShell">
  <aside className="crmSide">
   <Link href="/" className="crmLogo"><div><Sparkles size={18}/></div><span><b>EngageX</b><small>CRM Workspace</small></span></Link>
   <nav>{menu.map(([n,href,I],i)=><Link className={i===0?"active":""} href={href} key={n}><I size={18}/><span>{n}</span></Link>)}</nav>
   <div className="sideBottom"><small>PRODUCT BY</small><b>Savrdh Technology</b><button onClick={logout}><LogOut size={17}/> Sign out</button></div>
  </aside>
  <section className="crmMain">
   <header><div><small>ENGAGEX / OVERVIEW</small><h1>Good to see you.</h1></div><div className="crmHeaderActions"><button aria-label="Notifications"><Bell size={18}/></button><div className="adminAvatar">A</div><span><b>Administrator</b><small>{email}</small></span></div></header>
   {error&&<div className="dashboardError">{error}</div>}
   <div className="welcomeBand"><div><span>OMNICHANNEL WORKSPACE</span><h2>One place for every customer conversation.</h2><p>Manage audiences, campaigns and delivery across WhatsApp, SMS and Email.</p></div><Link className="welcomeAction" href="/app/campaigns">+ Create Campaign</Link></div>

   <div className="crmMetrics">
    <article><span>Total Contacts</span><strong>{s?.contacts??0}</strong><small>{s?.new_contacts??0} new in 30 days</small></article>
    <article><span>Active Contacts</span><strong>{s?.active_contacts??0}</strong><small>Eligible contacts</small></article>
    <article><span>Total Campaigns</span><strong>{s?.campaigns??0}</strong><small>{s?.running_campaigns??0} running / scheduled</small></article>
    <article><span>Messages Sent</span><strong>{s?.messages_sent??0}</strong><small>{s?.pending??0} pending</small></article>
    <article><span>Delivered</span><strong>{s?.delivered??0}</strong><small>{deliveryRate===null?"No delivery data":deliveryRate+"% delivery rate"}</small></article>
    <article><span>Failed</span><strong>{s?.failed??0}</strong><small>Provider failures</small></article>
    <article><span>WhatsApp</span><strong>{s?.whatsapp??0}</strong><small>Messages tracked</small></article>
    <article><span>SMS / Email</span><strong>{(s?.sms??0)+(s?.email??0)}</strong><small>{s?.sms??0} SMS · {s?.email??0} Email</small></article>
   </div>

   <div className="crmGrid">
    <article className="performance">
     <div className="cardTitle"><div><small>MESSAGE VOLUME</small><h3>Last 14 days</h3></div><span>Live database</span></div>
     {(data?.timeseries||[]).some(x=>Number(x.total)>0)?
      <div className="miniChart">{(data?.timeseries||[]).map(x=><div key={x.dt} className="miniBarWrap" title={x.dt+" · "+x.total}><div className="miniBar" style={{height:`${Math.max(4,(Number(x.total)/max)*100)}%`}}/><span>{new Date(x.dt).getDate()}</span></div>)}</div>:
      <div className="emptyChart"><BarChart3 size={34}/><b>Analytics will appear here</b><span>Launch campaigns to start tracking delivery performance.</span></div>}
    </article>
    <article>
     <div className="cardTitle"><div><small>CHANNELS</small><h3>Communication status</h3></div></div>
     <div className="channelStatus">
      <div><i className="wa"><MessageCircle/></i><span><b>WhatsApp</b><small>{s?.whatsapp??0} messages</small></span><Link href="/app/integrations">Setup</Link></div>
      <div><i className="sms"><MessageSquareText/></i><span><b>SMS</b><small>{s?.sms??0} messages</small></span><Link href="/app/integrations">Setup</Link></div>
      <div><i className="mail"><Mail/></i><span><b>Email</b><small>{s?.email??0} messages</small></span><Link href="/app/integrations">Setup</Link></div>
     </div>
    </article>
   </div>

   <div className="dashboardDual">
    <section className="dashPanel">
     <div className="cardTitle"><div><small>RECENT CAMPAIGNS</small><h3>Latest activity</h3></div><Link href="/app/campaigns">View all</Link></div>
     {data?.campaigns?.length?<table className="dashTable"><thead><tr><th>Campaign</th><th>Channels</th><th>Status</th></tr></thead><tbody>{data.campaigns.map(c=><tr key={c.id}><td>{c.name}</td><td>{c.channels.join(", ")}</td><td><span className="dashBadge">{c.status}</span></td></tr>)}</tbody></table>:<div className="dashEmpty">No campaigns yet.</div>}
    </section>
    <section className="dashPanel">
     <div className="cardTitle"><div><small>RECENT ACTIVITY</small><h3>Workspace log</h3></div></div>
     {data?.activity?.length?<div className="activityList">{data.activity.map(a=><div key={a.id}><span className="activityDot"/><div><b>{a.action.replaceAll("_"," ")}</b><small>{new Date(a.created_at).toLocaleString()}</small></div></div>)}</div>:<div className="dashEmpty">No recent activity.</div>}
    </section>
   </div>

   <div className="quickTitle"><small>QUICK ACTIONS</small><h3>Work faster in EngageX</h3></div>
   <div className="quickGrid quickFive">
    <article><Plus/><h4>Add Contact</h4><p>Create a customer record with channel consent.</p><Link className="quickAction" href="/app/contacts">Open Contacts →</Link></article>
    <article><Upload/><h4>Import Contacts</h4><p>Upload Excel/CSV and validate before import.</p><Link className="quickAction" href="/app/contacts">Import →</Link></article>
    <article><Megaphone/><h4>Create Campaign</h4><p>Build WhatsApp, SMS, Email or multi-channel campaigns.</p><Link className="quickAction" href="/app/campaigns">Create →</Link></article>
    <article><Send/><h4>Send Message</h4><p>Use consent-aware provider messaging.</p><Link className="quickAction" href="/app/campaigns">Send →</Link></article>
    <article><GitBranch/><h4>Create Automation</h4><p>Build a triggered customer journey.</p><Link className="quickAction" href="/app/automations">Automate →</Link></article>
   </div>
  </section>
 </main>
}