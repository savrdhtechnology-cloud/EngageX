"use client";

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard,
  ContactRound,
  Megaphone,
  MessageSquareText,
  Workflow,
  BarChart3,
  Bot,
  Users,
  CreditCard,
  Settings,
  Sparkles,
  LogOut,
  Bell,
  Globe,
  MessageCircle,
  ExternalLink,
  Send,
  X,
  Check,
  CheckCheck,
  Trash2,
  Clock,
} from 'lucide-react';
import { useApp } from '../../../lib/context';

interface CommercialShellProps {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', path: '/app/dashboard', icon: LayoutDashboard },
  { id: 'contacts', label: 'Contacts', path: '/app/contacts', icon: ContactRound },
  { id: 'campaigns', label: 'Campaigns', path: '/app/campaigns', icon: Megaphone },
  { id: 'messages', label: 'Live Inbox', path: '/app/messages', icon: MessageSquareText },
  { id: 'templates', label: 'Templates', path: '/app/templates', icon: MessageSquareText },
  { id: 'automations', label: 'Automations', path: '/app/automations', icon: Workflow },
  { id: 'analytics', label: 'Analytics', path: '/app/analytics', icon: BarChart3 },
  { id: 'integrations', label: 'Integrations', path: '/app/integrations', icon: Bot },
  { id: 'team', label: 'Team & Roles', path: '/app/team', icon: Users },
  { id: 'billing', label: 'Billing & Plan', path: '/app/billing', icon: CreditCard },
  { id: 'settings', label: 'Settings', path: '/app/settings', icon: Settings },
];

export default function CommercialShell({ title, subtitle, children }: CommercialShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const {
    userSession,
    logout,
    notifications,
    unreadNotificationsCount,
    markNotificationRead,
    markAllNotificationsRead,
    deleteNotification,
  } = useApp();

  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNotificationClick = (item: any) => {
    markNotificationRead(item.id);
    setNotifOpen(false);
    if (item.targetTab) {
      router.push(`/app/${item.targetTab}`);
    }
  };

  return (
    <main className="crmShell">
      {/* Left Sidebar */}
      <aside className="crmSide">
        <Link href="/app/dashboard" className="crmLogo">
          <div>
            <Sparkles size={18} />
          </div>
          <span>
            <b>EngageX</b>
            <small>CRM Workspace · Savrdh</small>
          </span>
        </Link>

        <nav>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const currentPath = pathname || ''; const isActive = currentPath === item.path || (item.path !== '/app/dashboard' && currentPath.startsWith(item.path));
            return (
              <Link
                key={item.id}
                href={item.path}
                className={isActive ? 'active' : ''}
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="sideBottom">
          <small>WORKSPACE ENGINE</small>
          <b>Savrdh Technology</b>
          <button
            onClick={() => {
              logout();
              router.push('/login');
            }}
          >
            <LogOut size={16} /> Sign out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <section className="crmMain">
        {/* Top Header */}
        <header>
          <div>
            <small style={{ letterSpacing: '0.8px', color: '#0891b2', fontWeight: 800 }}>
              SAVRDH TECHNOLOGY · ENGAGEX OMNICHANNEL CRM
            </small>
            <h1 style={{ margin: '4px 0 2px' }}>{title}</h1>
            <p className="pageSub" style={{ margin: 0 }}>{subtitle}</p>
          </div>

          <div className="crmHeaderActions">
            <Link
              href="/"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '5px',
                padding: '6px 12px',
                fontSize: '11px',
                fontWeight: 700,
                color: '#0891b2',
                background: '#e0f2fe',
                borderRadius: '8px',
                textDecoration: 'none',
              }}
            >
              <Globe size={13} /> View Website
            </Link>

            {/* Notification Bell Dropdown */}
            <div style={{ position: 'relative' }} ref={notifRef}>
              <button
                type="button"
                onClick={() => setNotifOpen(!notifOpen)}
                style={{
                  position: 'relative',
                  width: '36px',
                  height: '36px',
                  border: '1px solid #dce7ec',
                  background: notifOpen ? '#f0f9ff' : '#fff',
                  borderRadius: '10px',
                  color: notifOpen ? '#0284c7' : '#567485',
                  cursor: 'pointer',
                  display: 'grid',
                  placeItems: 'center',
                }}
                title="Notifications"
              >
                <Bell size={18} />
                {unreadNotificationsCount > 0 && (
                  <span
                    style={{
                      position: 'absolute',
                      top: '-4px',
                      right: '-4px',
                      background: '#ef4444',
                      color: '#fff',
                      fontSize: '9px',
                      fontWeight: 800,
                      borderRadius: '999px',
                      minWidth: '17px',
                      height: '17px',
                      display: 'grid',
                      placeItems: 'center',
                      padding: '0 4px',
                      border: '2px solid #ffffff',
                    }}
                  >
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>

              {notifOpen && (
                <div
                  style={{
                    position: 'absolute',
                    right: 0,
                    top: '46px',
                    width: '360px',
                    maxHeight: '480px',
                    background: '#ffffff',
                    borderRadius: '14px',
                    boxShadow: '0 20px 45px rgba(0, 0, 0, 0.16), 0 0 0 1px rgba(0, 0, 0, 0.05)',
                    zIndex: 100,
                    display: 'flex',
                    flexDirection: 'column',
                    overflow: 'hidden',
                  }}
                >
                  <div
                    style={{
                      padding: '12px 16px',
                      borderBottom: '1px solid #f1f5f9',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      background: '#f8fafc',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <b style={{ fontSize: '13px', color: '#0f172a' }}>Notifications</b>
                      {unreadNotificationsCount > 0 && (
                        <span
                          style={{
                            background: '#dbeafe',
                            color: '#1d4ed8',
                            fontSize: '10px',
                            fontWeight: 800,
                            padding: '1px 6px',
                            borderRadius: '999px',
                          }}
                        >
                          {unreadNotificationsCount} new
                        </span>
                      )}
                    </div>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      {unreadNotificationsCount > 0 && (
                        <button
                          type="button"
                          onClick={markAllNotificationsRead}
                          style={{
                            border: 0,
                            background: 'transparent',
                            color: '#0284c7',
                            fontSize: '11px',
                            fontWeight: 700,
                            cursor: 'pointer',
                          }}
                        >
                          Mark all read
                        </button>
                      )}
                      {notifications.length > 0 && (
                        <button
                          type="button"
                          onClick={() => notifications.forEach(n => deleteNotification(n.id))}
                          style={{
                            border: 0,
                            background: 'transparent',
                            color: '#94a3b8',
                            fontSize: '11px',
                            cursor: 'pointer',
                          }}
                          title="Clear all"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                  </div>

                  <div style={{ overflowY: 'auto', maxHeight: '380px' }}>
                    {notifications.length === 0 ? (
                      <div style={{ padding: '32px 16px', textAlign: 'center', color: '#94a3b8', fontSize: '12px' }}>
                        <Bell size={24} style={{ margin: '0 auto 8px', opacity: 0.4 }} />
                        <p style={{ margin: 0 }}>No notifications right now.</p>
                      </div>
                    ) : (
                      notifications.map((item) => (
                        <div
                          key={item.id}
                          onClick={() => handleNotificationClick(item)}
                          style={{
                            padding: '12px 16px',
                            borderBottom: '1px solid #f1f5f9',
                            cursor: 'pointer',
                            background: item.read ? '#ffffff' : '#f0f9ff',
                            transition: 'background 0.15s ease',
                          }}
                        >
                          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                            <span style={{ fontSize: '12px', fontWeight: item.read ? 600 : 800, color: '#0f172a' }}>
                              {item.title}
                            </span>
                            <span style={{ fontSize: '10px', color: '#94a3b8' }}>{item.time}</span>
                          </div>
                          <p style={{ margin: 0, fontSize: '11px', color: '#475569', lineHeight: 1.4 }}>
                            {item.description}
                          </p>
                          {item.targetTab && (
                            <span style={{ display: 'inline-block', marginTop: '6px', fontSize: '10px', color: '#0284c7', fontWeight: 700 }}>
                              Open {item.targetTab} →
                            </span>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="adminAvatar">
              {userSession.name ? userSession.name.charAt(0).toUpperCase() : 'A'}
            </div>
            <span>
              <b>{userSession.name}</b>
              <small>{userSession.email}</small>
            </span>
          </div>
        </header>

        {/* Page Content */}
        {children}
      </section>
    </main>
  );
}
