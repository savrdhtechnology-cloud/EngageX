"use client";
import { useEffect,useState } from "react";
import CommercialShell from "../components/CommercialShell";
import { apiFetch } from "../../../lib/client-api";
type A={sent:number;delivered:number;failed:number;pending:number;read:number;clicks:number;replies:number};
export default function Analytics(){
 const [a,setA]=useState<A>({sent:0,delivered:0,failed:0,pending:0,read:0,clicks:0,replies:0}),[error,setError]=useState("");
 useEffect(()=>{apiFetch<A>("/api/analytics").then(setA).catch(e=>setError(e.message))},[]);
 const rate=a.sent?Math.round(a.delivered/a.sent*100):null;
 return <CommercialShell title="Analytics" subtitle="Delivery, engagement, reply and campaign performance reporting.">
  {error&&<div className="notice errorNotice">{error}</div>}
  <div className="metricGrid"><article><span>Total Sent</span><strong>{a.sent}</strong><small>All channels</small></article><article><span>Delivered</span><strong>{a.delivered}</strong><small>{rate===null?"No data":rate+"% delivery rate"}</small></article><article><span>Failed</span><strong>{a.failed}</strong><small>Provider failures</small></article><article><span>Replies</span><strong>{a.replies}</strong><small>Customer responses</small></article></div>
  <div className="metricGrid"><article><span>Read</span><strong>{a.read}</strong><small>WhatsApp / Email</small></article><article><span>Clicks</span><strong>{a.clicks}</strong><small>Tracked links</small></article><article><span>Pending</span><strong>{a.pending}</strong><small>Queued / pending</small></article><article><span>Delivery Rate</span><strong>{rate===null?"—":rate+"%"}</strong><small>Database-derived</small></article></div>
  <section className="panel"><div className="commercialToolbar"><div><h3>Campaign Performance</h3><p>Use date, campaign, channel, group and segment filters as data grows.</p></div><button className="cbtn secondary" onClick={()=>window.print()}>Export / Print Report</button></div>{a.sent===0?<div className="emptyBox"><div><b>No analytics data yet</b><p>Send campaigns to start measuring performance.</p></div></div>:<div className="analyticsBars"><div><span>Delivered</span><b style={{width:Math.max(2,a.delivered/a.sent*100)+"%"}}/></div><div><span>Failed</span><b style={{width:Math.max(2,a.failed/a.sent*100)+"%"}}/></div><div><span>Read</span><b style={{width:Math.max(2,a.read/a.sent*100)+"%"}}/></div><div><span>Replies</span><b style={{width:Math.max(2,a.replies/a.sent*100)+"%"}}/></div></div>}</section>
 </CommercialShell>
}