"use client";
import { useEffect,useState } from "react";
import CommercialShell from "../components/CommercialShell";
import { apiFetch } from "../../../lib/client-api";

type Workspace={id:string;name:string;slug:string;plan:string;status:string};
type Audit={id:string;action:string;resource_type:string|null;resource_id:string|null;ip:string|null;metadata:Record<string,unknown>;created_at:string};

export default function Settings(){
 const [workspace,setWorkspace]=useState<Workspace|null>(null),[name,setName]=useState(""),[audits,setAudits]=useState<Audit[]>([]),[notice,setNotice]=useState(""),[error,setError]=useState("");
 async function load(){try{const [w,a]=await Promise.all([apiFetch<Workspace>("/api/workspace"),apiFetch<Audit[]>("/api/audit")]);setWorkspace(w);setName(w?.name||"");setAudits(a)}catch(e){setError(e instanceof Error?e.message:"Could not load settings")}}
 useEffect(()=>{load()},[]);
 async function saveWorkspace(){try{await apiFetch("/api/workspace",{method:"PUT",body:JSON.stringify({name,plan:workspace?.plan})});setNotice("Workspace profile updated.");await load()}catch(e){setError(e instanceof Error?e.message:"Settings update failed")}}
 return <CommercialShell title="Settings" subtitle="Workspace profile, security, privacy, API and audit controls.">
  {error&&<div className="notice errorNotice">{error}</div>}{notice&&<div className="notice">{notice}</div>}
  <div className="settingsLayout">
   <section className="panel"><h3>Workspace Profile</h3><p>Company information and core workspace settings.</p><div className="formGrid"><div className="field"><label>Company / Workspace Name</label><input value={name} onChange={e=>setName(e.target.value)}/></div><div className="field"><label>Workspace Slug</label><input value={workspace?.slug||""} disabled/></div><div className="field"><label>Plan</label><input value={workspace?.plan||""} disabled/></div><div className="field"><label>Status</label><input value={workspace?.status||""} disabled/></div></div><div className="modalActions"><button className="cbtn primary" onClick={saveWorkspace}>Save Workspace</button></div></section>
   <section className="panel"><h3>Security & Access</h3><p>Supabase Auth sessions, role-based access control and server-side API authentication protect the CRM. Provider secrets are never returned to the frontend.</p><div className="settingsChecklist"><span>Secure authentication</span><span>Workspace isolation / RLS</span><span>Role-based permissions</span><span>Encrypted provider credentials</span></div></section>
  </div>
  <div className="roleCards" style={{marginTop:14}}>
   {[
    ["Branding","Logo, brand color, timezone and currency can be layered onto workspace preferences."],
    ["Notifications","Configure campaign, integration and system alerts."],
    ["Data & Privacy","Consent, retention, unsubscribe and export controls."],
    ["Communication Preferences","Default sender and channel behavior."],
    ["API Keys","Server-side API key model is ready; keys should be shown only once when generated."],
    ["Webhooks","WhatsApp, SMS and Email webhook endpoints use idempotent provider event IDs."]
   ].map(([a,b])=><article key={a}><h4>{a}</h4><p>{b}</p></article>)}
  </div>
  <section className="panel" style={{marginTop:14}}><h3>Audit Log</h3><p>Security-relevant workspace actions are recorded in the database.</p>{audits.length===0?<div className="emptyBox"><b>No audit activity yet</b></div>:<div className="responsiveTable"><table className="dataTable"><thead><tr><th>Action</th><th>Resource</th><th>Time</th></tr></thead><tbody>{audits.map(a=><tr key={a.id}><td>{a.action.replaceAll("_"," ")}</td><td>{a.resource_type||"—"}</td><td>{new Date(a.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>}</section>
 </CommercialShell>
}