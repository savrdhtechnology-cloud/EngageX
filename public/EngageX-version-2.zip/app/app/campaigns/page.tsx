"use client";
import { useEffect,useMemo,useState } from "react";
import CommercialShell from "../components/CommercialShell";
import { apiFetch } from "../../../lib/client-api";

type Campaign={id:string;name:string;status:string;channels:string[];scheduled_at:string|null;message_subject:string|null;message_body:string|null;created_at:string};
export default function Campaigns(){
 const [rows,setRows]=useState<Campaign[]>([]),[open,setOpen]=useState(false),[notice,setNotice]=useState(""),[error,setError]=useState(""),[loading,setLoading]=useState(true);
 const [name,setName]=useState(""),[subject,setSubject]=useState(""),[body,setBody]=useState(""),[channels,setChannels]=useState<string[]>([]),[sendMode,setSendMode]=useState("draft"),[scheduledAt,setScheduledAt]=useState("");
 async function load(){setLoading(true);try{setRows(await apiFetch<Campaign[]>("/api/campaigns"))}catch(e){setError(e instanceof Error?e.message:"Could not load campaigns")}finally{setLoading(false)}}
 useEffect(()=>{load()},[]);
 const counts=useMemo(()=>({draft:rows.filter(x=>x.status==="draft").length,scheduled:rows.filter(x=>x.status==="scheduled").length,running:rows.filter(x=>["queued","running","sending"].includes(x.status)).length,completed:rows.filter(x=>x.status==="completed").length}),[rows]);
 function toggle(c:string){setChannels(s=>s.includes(c)?s.filter(x=>x!==c):[...s,c])}
 async function create(){
  setError("");
  if(!name.trim()){setError("Campaign name is required.");return}
  if(!channels.length){setError("Select at least one channel.");return}
  if(!body.trim()){setError("Message body is required.");return}
  if(!confirm("Create this campaign? Sending will only include contacts with appropriate channel consent."))return;
  try{
   const r=await apiFetch<{id:string}>("/api/campaigns",{method:"POST",body:JSON.stringify({name,channels,subject,body,send_mode:sendMode,scheduled_at:sendMode==="schedule"&&scheduledAt?new Date(scheduledAt).toISOString():null})});
   if(sendMode==="now"){const q:any=await apiFetch("/api/campaigns/"+r.id+"/send",{method:"POST"});setNotice(`Campaign queued with ${q.queued_jobs||0} consent-eligible message jobs.`)}
   else setNotice(sendMode==="schedule"?"Campaign scheduled.":"Campaign saved as draft.");
   setOpen(false);setName("");setSubject("");setBody("");setChannels([]);setSendMode("draft");setScheduledAt("");await load();
  }catch(e){setError(e instanceof Error?e.message:"Campaign creation failed")}
 }
 async function queueCampaign(id:string){if(!confirm("Queue this campaign now? Only opted-in contacts will be included."))return;try{const q:any=await apiFetch("/api/campaigns/"+id+"/send",{method:"POST"});setNotice(`Queued ${q.queued_jobs||0} message jobs.`);await load()}catch(e){setError(e instanceof Error?e.message:"Could not queue campaign")}}
 return <CommercialShell title="Campaigns" subtitle="WhatsApp, SMS, Email and multi-channel campaign management.">
  {error&&<div className="notice errorNotice">{error}</div>}{notice&&<div className="notice">{notice}</div>}
  <div className="commercialToolbar"><div className="leftActions"><span className="filterPill">WhatsApp</span><span className="filterPill">SMS</span><span className="filterPill">Email</span><span className="filterPill">Multi-channel</span></div><button className="cbtn primary" onClick={()=>setOpen(true)}>+ New Campaign</button></div>
  <div className="metricGrid"><article><span>Draft</span><strong>{counts.draft}</strong><small>Not launched</small></article><article><span>Scheduled</span><strong>{counts.scheduled}</strong><small>Upcoming</small></article><article><span>Queued / Running</span><strong>{counts.running}</strong><small>Background delivery</small></article><article><span>Completed</span><strong>{counts.completed}</strong><small>Finished</small></article></div>
  <section className="panel"><h3>Campaigns</h3><p>Create, schedule and track consent-aware single-channel or multi-channel campaigns.</p>
   {loading?<div className="emptyBox"><b>Loading campaigns…</b></div>:rows.length===0?<div className="emptyBox"><div><b>No campaigns yet</b><p>Create your first campaign to start.</p></div></div>:
   <div className="responsiveTable"><table className="dataTable"><thead><tr><th>Name</th><th>Channels</th><th>Status</th><th>Scheduled</th><th>Actions</th></tr></thead><tbody>{rows.map(c=><tr key={c.id}><td><b>{c.name}</b><small className="cellSub">{new Date(c.created_at).toLocaleString()}</small></td><td>{c.channels.join(", ")}</td><td><span className="status">{c.status}</span></td><td>{c.scheduled_at?new Date(c.scheduled_at).toLocaleString():"—"}</td><td>{["draft","scheduled","paused"].includes(c.status)&&<button className="tableAction" onClick={()=>queueCampaign(c.id)}>Queue Now</button>}</td></tr>)}</tbody></table></div>}
  </section>
  {open&&<div className="modalBackdrop"><div className="modalCard"><div className="modalHead"><div><small>CAMPAIGN WIZARD</small><h3>Create Campaign</h3></div><button onClick={()=>setOpen(false)}>×</button></div>
   <div className="stepFlow" style={{marginBottom:16}}><span>1 Campaign</span><i>→</i><span>2 Audience</span><i>→</i><span>3 Channels</span><i>→</i><span>4 Message</span><i>→</i><span>5 Schedule</span><i>→</i><span>6 Review</span></div>
   <div className="formGrid">
    <div className="field full"><label>Campaign Name</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="September customer update"/></div>
    <div className="field full"><label>Audience</label><select disabled><option>All consent-eligible active contacts</option></select><small className="fieldHint">Groups and dynamic segments are part of the next audience selector layer.</small></div>
    <div className="field full"><label>Channels</label><div className="channelChecks">{["whatsapp","sms","email"].map(c=><label key={c}><input type="checkbox" checked={channels.includes(c)} onChange={()=>toggle(c)}/>{c.toUpperCase()}</label>)}</div></div>
    <div className="field full"><label>Subject (Email)</label><input value={subject} onChange={e=>setSubject(e.target.value)} placeholder="Optional email subject"/></div>
    <div className="field full"><label>Message</label><textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="Hello {{first_name}}, ..."/><small className="fieldHint">Personalization variables are validated by the provider/template layer before delivery.</small></div>
    <div className="field"><label>Send Option</label><select value={sendMode} onChange={e=>setSendMode(e.target.value)}><option value="draft">Save Draft</option><option value="now">Send Now</option><option value="schedule">Schedule</option></select></div>
    <div className="field"><label>Schedule Time</label><input type="datetime-local" disabled={sendMode!=="schedule"} value={scheduledAt} onChange={e=>setScheduledAt(e.target.value)}/></div>
   </div>
   <div className="reviewBox"><b>Review</b><span>{name||"Untitled campaign"} · {channels.length?channels.join(", "):"No channel selected"} · {sendMode}</span><small>Only contacts with the required WhatsApp/SMS/Email opt-in are eligible for sending.</small></div>
   <div className="modalActions"><button className="cbtn secondary" onClick={()=>setOpen(false)}>Cancel</button><button className="cbtn primary" onClick={create}>{sendMode==="now"?"Create & Queue":"Save Campaign"}</button></div>
  </div></div>}
 </CommercialShell>
}