"use client";
import { useEffect,useMemo,useState } from "react";
import CommercialShell from "../components/CommercialShell";
import { apiFetch } from "../../../lib/client-api";

type Template={id:string;name:string;channel:"whatsapp"|"sms"|"email";subject:string|null;body:string;status:string;created_at:string};
const allowed=["first_name","last_name","company","mobile","email"];
export default function Templates(){
 const [rows,setRows]=useState<Template[]>([]),[loading,setLoading]=useState(true),[open,setOpen]=useState(false),[error,setError]=useState(""),[notice,setNotice]=useState("");
 const [name,setName]=useState(""),[channel,setChannel]=useState("whatsapp"),[subject,setSubject]=useState(""),[body,setBody]=useState("");
 async function load(){setLoading(true);try{setRows(await apiFetch<Template[]>("/api/templates"))}catch(e){setError(e instanceof Error?e.message:"Could not load templates")}finally{setLoading(false)}}
 useEffect(()=>{load()},[]);
 const counts=useMemo(()=>({whatsapp:rows.filter(x=>x.channel==="whatsapp").length,sms:rows.filter(x=>x.channel==="sms").length,email:rows.filter(x=>x.channel==="email").length}),[rows]);
 function variables(text:string){return [...text.matchAll(/{{\s*([a-zA-Z0-9_]+)\s*}}/g)].map(m=>m[1])}
 async function save(){setError("");const vars=variables(body);const bad=vars.filter(v=>!allowed.includes(v));if(!name.trim()||!body.trim()){setError("Template name and body are required.");return}if(bad.length){setError("Unsupported variables: "+bad.join(", "));return}try{await apiFetch("/api/templates",{method:"POST",body:JSON.stringify({name,channel,subject,body})});setNotice("Template created.");setOpen(false);setName("");setSubject("");setBody("");await load()}catch(e){setError(e instanceof Error?e.message:"Template creation failed")}}
 return <CommercialShell title="Communication Templates" subtitle="Reusable personalized templates for WhatsApp, SMS and Email.">
  {error&&<div className="notice errorNotice">{error}</div>}{notice&&<div className="notice">{notice}</div>}
  <div className="commercialToolbar"><div className="leftActions"><span className="filterPill">WhatsApp {counts.whatsapp}</span><span className="filterPill">SMS {counts.sms}</span><span className="filterPill">Email {counts.email}</span></div><button className="cbtn primary" onClick={()=>setOpen(true)}>+ New Template</button></div>
  <section className="panel"><h3>Template Library</h3><p>Create channel-specific content and validate personalization variables before sending.</p>
   {loading?<div className="emptyBox"><b>Loading templates…</b></div>:rows.length===0?<div className="emptyBox"><div><b>No templates yet</b><p>Create a reusable communication template.</p></div></div>:
   <div className="responsiveTable"><table className="dataTable"><thead><tr><th>Name</th><th>Channel</th><th>Status</th><th>Preview</th><th>Created</th></tr></thead><tbody>{rows.map(t=><tr key={t.id}><td><b>{t.name}</b></td><td>{t.channel}</td><td><span className="status">{t.status}</span></td><td>{t.body.slice(0,80)}{t.body.length>80?"…":""}</td><td>{new Date(t.created_at).toLocaleDateString()}</td></tr>)}</tbody></table></div>}
  </section>
  {open&&<div className="modalBackdrop"><div className="modalCard"><div className="modalHead"><div><small>NEW TEMPLATE</small><h3>Create Communication Template</h3></div><button onClick={()=>setOpen(false)}>×</button></div><div className="formGrid">
   <div className="field"><label>Name</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Welcome message"/></div>
   <div className="field"><label>Channel</label><select value={channel} onChange={e=>setChannel(e.target.value)}><option value="whatsapp">WhatsApp</option><option value="sms">SMS</option><option value="email">Email</option></select></div>
   <div className="field full"><label>Subject (Email only)</label><input value={subject} onChange={e=>setSubject(e.target.value)} placeholder="Welcome to {{company}}"/></div>
   <div className="field full"><label>Message</label><textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="Hello {{first_name}}, ..."/></div>
  </div><div className="variableHelp"><b>Allowed variables</b>{allowed.map(v=><code key={v}>{"{{"+v+"}}"}</code>)}</div><div className="previewCard"><b>Preview</b><p>{body||"Your message preview will appear here."}</p></div><div className="modalActions"><button className="cbtn secondary" onClick={()=>setOpen(false)}>Cancel</button><button className="cbtn primary" onClick={save}>Create Template</button></div></div></div>}
 </CommercialShell>
}