"use client";
import { useEffect,useMemo,useState } from "react";
import CommercialShell from "../components/CommercialShell";
import { apiFetch } from "../../../lib/client-api";
type Integration={id:string;provider:string;channel:string;status:string;config:Record<string,unknown>};
const presets=[
 {title:"WhatsApp Business",provider:"whatsapp_meta",channel:"whatsapp",desc:"Official Meta WhatsApp Business Platform / Cloud API"},
 {title:"Email Provider",provider:"resend",channel:"email",desc:"Resend transactional and campaign email"},
 {title:"SMS Provider",provider:"sms_generic",channel:"sms",desc:"Provider abstraction for compliant SMS services"}
];
export default function Integrations(){
 const [rows,setRows]=useState<Integration[]>([]),[selected,setSelected]=useState<(typeof presets)[number]|null>(null),[secret,setSecret]=useState(""),[phoneId,setPhoneId]=useState(""),[notice,setNotice]=useState(""),[error,setError]=useState(""),[testing,setTesting]=useState(false);
 async function load(){try{setRows(await apiFetch<Integration[]>("/api/integrations"))}catch(e){setError(e instanceof Error?e.message:"Could not load integrations")}}
 useEffect(()=>{load()},[]);
 const map=useMemo(()=>new Map(rows.map(x=>[x.provider,x])),[rows]);
 async function test(){if(!selected||!secret){setError("Credential is required.");return}setTesting(true);setError("");try{const r:any=await apiFetch("/api/integrations/test",{method:"POST",body:JSON.stringify({provider:selected.provider,secret,phone_number_id:phoneId})});setNotice(r.message||"Connection verified.")}catch(e){setError(e instanceof Error?e.message:"Connection test failed")}finally{setTesting(false)}}
 async function save(){if(!selected||!secret){setError("Credential is required.");return}try{await apiFetch("/api/integrations/credentials",{method:"POST",body:JSON.stringify({provider:selected.provider,channel:selected.channel,secret,config:selected.channel==="whatsapp"?{phone_number_id:phoneId}:{}})});setNotice(selected.title+" configured. Secret stored encrypted on the server.");setSelected(null);setSecret("");setPhoneId("");await load()}catch(e){setError(e instanceof Error?e.message:"Could not save integration")}}
 async function disconnect(p:(typeof presets)[number]){try{await apiFetch("/api/integrations",{method:"POST",body:JSON.stringify({provider:p.provider,channel:p.channel,status:"disconnected",config:{}})});setNotice(p.title+" disconnected.");await load()}catch(e){setError(e instanceof Error?e.message:"Disconnect failed")}}
 return <CommercialShell title="Integrations" subtitle="Connect, configure and test communication providers without exposing API secrets.">
  {error&&<div className="notice errorNotice">{error}</div>}{notice&&<div className="notice">{notice}</div>}
  <div className="channelCards">{presets.map(p=>{const current=map.get(p.provider);return <article key={p.provider}><div className="integrationStatus"><span>{p.channel.toUpperCase()}</span><b className={current?.status==="configured"?"connected":""}>{current?.status||"Not connected"}</b></div><h4>{p.title}</h4><p>{p.desc}.</p><div className="integrationActions"><button className="cbtn primary" onClick={()=>setSelected(p)}>{current?.status==="configured"?"Configure":"Connect"}</button>{current&&current.status!=="disconnected"&&<button className="cbtn secondary" onClick={()=>disconnect(p)}>Disconnect</button>}</div></article>})}</div>
  <section className="panel" style={{marginTop:14}}><h3>Security</h3><p>Credentials are submitted only to server routes, encrypted before storage and are never returned to the browser. Provider status is not marked configured until credentials are saved.</p></section>
  {selected&&<div className="modalBackdrop"><div className="modalCard compactModal"><div className="modalHead"><div><small>PROVIDER SETUP</small><h3>{selected.title}</h3></div><button onClick={()=>setSelected(null)}>×</button></div><div className="formGrid">{selected.channel==="whatsapp"&&<div className="field full"><label>Phone Number ID</label><input value={phoneId} onChange={e=>setPhoneId(e.target.value)} placeholder="Meta phone number ID"/></div>}<div className="field full"><label>{selected.provider==="resend"?"API Key":"Provider Secret / Token"}</label><input type="password" value={secret} onChange={e=>setSecret(e.target.value)} autoComplete="new-password" placeholder="Stored encrypted; never shown again"/></div></div><div className="modalActions"><button className="cbtn secondary" onClick={test}>{testing?"Testing…":"Test Connection"}</button><button className="cbtn primary" onClick={save}>Save Securely</button></div></div></div>}
 </CommercialShell>
}