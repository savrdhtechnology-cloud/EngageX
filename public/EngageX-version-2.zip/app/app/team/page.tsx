"use client";
import { useEffect,useState } from "react";
import CommercialShell from "../components/CommercialShell";
import { apiFetch } from "../../../lib/client-api";
type Member={id:string;user_id:string;role:string;status:string;email:string;created_at:string};
export default function Team(){
 const [rows,setRows]=useState<Member[]>([]),[open,setOpen]=useState(false),[email,setEmail]=useState(""),[role,setRole]=useState("employee"),[notice,setNotice]=useState(""),[error,setError]=useState("");
 async function load(){try{setRows(await apiFetch<Member[]>("/api/team"))}catch(e){setError(e instanceof Error?e.message:"Could not load team")}}
 useEffect(()=>{load()},[]);
 async function invite(){if(!email.trim()){setError("Email is required.");return}try{await apiFetch("/api/team/invite",{method:"POST",body:JSON.stringify({email,role})});setNotice("Invite sent. The member will be linked to this workspace after accepting.");setOpen(false);setEmail("");await load()}catch(e){setError(e instanceof Error?e.message:"Invite failed")}}
 const permissions:Record<string,string>={
  Owner:"Full access including billing, team and settings",
  Admin:"Manage contacts, campaigns, analytics, integrations and team",
  Manager:"Manage contacts, campaigns and analytics",
  Employee:"Work with assigned communication and contact tasks",
  Viewer:"Read-only access to permitted modules"
 };
 return <CommercialShell title="Team & Roles" subtitle="Control workspace access with role-based permissions.">
  {error&&<div className="notice errorNotice">{error}</div>}{notice&&<div className="notice">{notice}</div>}
  <div className="commercialToolbar"><div/><button className="cbtn primary" onClick={()=>setOpen(true)}>+ Invite Member</button></div>
  <div className="roleCards">{Object.entries(permissions).map(([name,desc])=><article key={name}><h4>{name}</h4><p>{desc}.</p></article>)}</div>
  <section className="panel" style={{marginTop:14}}><h3>Workspace Members</h3><p>Owner has full access. Other roles should be limited by server-side permissions.</p>{rows.length===0?<div className="emptyBox"><b>No team members found</b></div>:<div className="responsiveTable"><table className="dataTable"><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Added</th></tr></thead><tbody>{rows.map(m=><tr key={m.id}><td>{m.email}</td><td>{m.role}</td><td><span className="status">{m.status}</span></td><td>{new Date(m.created_at).toLocaleDateString()}</td></tr>)}</tbody></table></div>}</section>
  {open&&<div className="modalBackdrop"><div className="modalCard compactModal"><div className="modalHead"><div><small>INVITE TEAM MEMBER</small><h3>Add workspace access</h3></div><button onClick={()=>setOpen(false)}>×</button></div><div className="formGrid"><div className="field full"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="user@company.com"/></div><div className="field full"><label>Role</label><select value={role} onChange={e=>setRole(e.target.value)}><option value="admin">Admin</option><option value="manager">Manager</option><option value="employee">Employee</option><option value="viewer">Viewer</option></select></div></div><div className="modalActions"><button className="cbtn secondary" onClick={()=>setOpen(false)}>Cancel</button><button className="cbtn primary" onClick={invite}>Send Invite</button></div></div></div>}
 </CommercialShell>
}