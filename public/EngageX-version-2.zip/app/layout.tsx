import type { Metadata } from "next";
import "./globals.css";
import "./animations.css";

export const metadata: Metadata = {
  title: "EngageX | Connect. Engage. Grow.",
  description:
    "EngageX by Savrdh Technology — one platform for WhatsApp, SMS and Email customer communication.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
