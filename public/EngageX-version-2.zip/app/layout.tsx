import type { Metadata } from "next";
import { Providers } from "./providers";
import "./globals.css";
import "./animations.css";
import "./app/components/commercial.css";
import "./app/dashboard/dashboard.css";
import "./login/login.css";

export const metadata: Metadata = {
  title: "EngageX | Omnichannel Customer Communication CRM",
  description:
    "EngageX by Savrdh Technology — enterprise platform for WhatsApp, SMS and Email customer campaigns, live inbox, and automated retention workflows.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
