import Link from 'next/link';

export default function NotFound() {
  return (
    <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', fontFamily: 'sans-serif', background: '#f8fafc' }}>
      <div style={{ textAlign: 'center', padding: '32px' }}>
        <h1 style={{ fontSize: '48px', margin: '0 0 12px', color: '#0f172a' }}>404</h1>
        <p style={{ color: '#64748b', margin: '0 0 24px', fontSize: '14px' }}>The requested page could not be found.</p>
        <Link
          href="/"
          style={{
            display: 'inline-block',
            padding: '10px 20px',
            background: '#0891b2',
            color: '#fff',
            borderRadius: '8px',
            textDecoration: 'none',
            fontWeight: 700,
            fontSize: '12px',
          }}
        >
          Return to Home
        </Link>
      </div>
    </div>
  );
}
