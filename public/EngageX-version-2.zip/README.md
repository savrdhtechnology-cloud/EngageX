# EngageX v2.0 - Omnichannel Customer Communication CRM

Developed by Savrdh Technology.

EngageX is a complete, enterprise-grade Omnichannel Customer Communication and CRM platform engineered for WhatsApp Business Cloud API, Carrier DLT SMS, and Rich Transactional/Marketing Email.

## Features in Version 2.0

- **Commercial CRM Dashboard**: Interactive KPI metrics, 14-day omnichannel dispatch volume timeseries graph with zero-shift hover & pin features, 24-hour dispatch heatmap curve, SLA telemetry, and quick launchpad.
- **Omnichannel Live Inbox**: Two-way interactive conversations across WhatsApp, SMS, and Email with quick reply templates and real-time simulator.
- **Audience & Contact Directory**: Full contact management, custom tagging, channel opt-in/consent tracking, and direct Excel (.xlsx) / CSV spreadsheet import & export.
- **Broadcast Campaigns**: Create and queue targeted multi-channel campaigns with audience filters, scheduling, and live delivery telemetry.
- **Interactive Template Studio**: WhatsApp pre-approved templates, DLT compliant SMS templates, and rich HTML email templates with dynamic variable tags (`{{name}}`, `{{company}}`).
- **Visual Automation Builder**: Drag-and-drop workflow builder connecting trigger events, delay timers, WhatsApp messages, conditions, and SMS fallbacks.
- **Analytics & Funnel Intelligence**: Deep delivery and conversion funnels, latency benchmarks, read receipts, and printable/exportable JSON reports.
- **Integrations Hub**: Meta WhatsApp Business Cloud API, Carrier SMS (DLT Entity ID / Header), Resend/SendGrid Email, and Webhook dispatchers with live connection testers.
- **Team & RBAC**: Multi-user workspace with Granular Role-Based Access Control (Super Admin, Campaign Manager, Support Agent, Compliance Officer).
- **Billing & Message Credits**: Live usage meters for WhatsApp conversations, SMS credits, and Email quota with top-up simulation.
- **Regulatory Compliance & Audit**: TRAI DLT Entity registration compliance and complete workspace audit trail logs.

## Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build production bundle
npm run build
```

## Tech Stack

- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS + Custom Commercial CRM Design System
- **Icons**: Lucide React
- **Data Parsing**: XLSX for Spreadsheet imports
