import { supabase } from "./supabase";
export async function apiFetch<T=unknown>(path:string,init:RequestInit={}) {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("Not authenticated");
  const headers = new Headers(init.headers);
  headers.set("Authorization",`Bearer ${token}`);
  if (!(init.body instanceof FormData) && init.body && !headers.has("Content-Type")) headers.set("Content-Type","application/json");
  const res = await fetch(path,{...init,headers});
  const payload = await res.json();
  if (!res.ok || payload?.success===false) throw new Error(payload?.error?.message||"Request failed");
  return payload.data as T;
}
