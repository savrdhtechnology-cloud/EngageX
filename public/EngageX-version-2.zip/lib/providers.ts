export type Channel = "whatsapp" | "sms" | "email";
export type ProviderSendInput = { to: string; subject?: string | null; body: string; metadata?: Record<string,unknown> };
export type ProviderSendResult = { providerMessageId: string; status: "sent" | "queued" };

export interface MessageProvider {
  channel: Channel;
  testConnection(): Promise<{ ok: boolean; message: string }>;
  send(input: ProviderSendInput): Promise<ProviderSendResult>;
}

export interface SmsProvider extends MessageProvider { channel: "sms" }
export interface EmailProvider extends MessageProvider { channel: "email" }
export interface WhatsAppProvider extends MessageProvider { channel: "whatsapp" }

export function requireProviderConfiguration(channel: Channel): never {
  throw new Error(`PROVIDER_NOT_CONFIGURED:${channel}`);
}
