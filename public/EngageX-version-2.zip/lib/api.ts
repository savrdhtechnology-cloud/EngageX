export function ok(data: unknown, init: ResponseInit = {}) {
  return Response.json({ success: true, data }, { status: 200, ...init });
}
export function fail(code: string, message: string, status = 400) {
  return Response.json({ success: false, error: { code, message } }, { status });
}
export function apiError(error: unknown) {
  const msg = error instanceof Error ? error.message : "UNKNOWN_ERROR";
  if (msg === "UNAUTHORIZED") return fail("UNAUTHORIZED", "Authentication required", 401);
  return fail("REQUEST_FAILED", msg === "UNKNOWN_ERROR" ? "Request failed" : msg, 400);
}
