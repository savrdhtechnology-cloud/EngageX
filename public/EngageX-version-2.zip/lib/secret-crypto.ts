import crypto from "node:crypto";
export function encryptSecret(value:string){
 const seed=process.env.PROVIDER_ENCRYPTION_KEY;
 if(!seed)throw new Error("PROVIDER_ENCRYPTION_KEY_NOT_CONFIGURED");
 const key=crypto.createHash("sha256").update(seed).digest();
 const iv=crypto.randomBytes(12);
 const cipher=crypto.createCipheriv("aes-256-gcm",key,iv);
 const encrypted=Buffer.concat([cipher.update(value,"utf8"),cipher.final()]);
 const tag=cipher.getAuthTag();
 return Buffer.concat([iv,tag,encrypted]);
}
