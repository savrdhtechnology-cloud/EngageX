import test from "node:test";
import assert from "node:assert/strict";

function normalizeEmail(v){return (v||"").trim().toLowerCase()}
function normalizePhone(v){return (v||"").replace(/[^+\d]/g,"")}
function canSend(channel,c){return channel==="whatsapp"?!!c.whatsapp_consent:channel==="sms"?!!c.sms_consent:!!c.email_consent}

test("email normalization",()=>assert.equal(normalizeEmail(" Test@Example.COM "),"test@example.com"));
test("phone normalization",()=>assert.equal(normalizePhone("+91 99999-00000"),"+919999900000"));
test("channel consent blocks non-opted-in sends",()=>{
  const c={whatsapp_consent:true,sms_consent:false,email_consent:false};
  assert.equal(canSend("whatsapp",c),true);
  assert.equal(canSend("sms",c),false);
  assert.equal(canSend("email",c),false);
});
